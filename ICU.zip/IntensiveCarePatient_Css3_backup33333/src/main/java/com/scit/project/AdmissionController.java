package com.scit.project;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.AdmissionRepository;
import com.scit.project.vo.Admission;
import com.scit.project.vo.AdmissionCount;
import com.scit.project.vo.Patient;


/**
 * Handles requests for the application home page.
 */
@Controller
public class AdmissionController {
	
	@Autowired
	AdmissionRepository repository;
	
	//환자 입원시 Admission 추가
		@RequestMapping(value ="insertAdmission",method = RequestMethod.POST)
		public @ResponseBody int  insertAdmission(Patient patient) {
			System.out.println("insertAdmission : " + patient);
		    //System.out.println(patient);
			int result =repository.insertAdmission(patient);
			
			return result;
		}
		
		@RequestMapping(value ="admissionEndDateUpdate",method = RequestMethod.POST)
		public @ResponseBody int  admissionEndDateUpdate(String p_Num) {

		    //System.out.println(patient);
			int result = repository.admissionEndDateUpdate(p_Num);
			return result;
		}
		
		 @RequestMapping(value = "/selectAdmissionCount", method = RequestMethod.POST)
         public @ResponseBody List<AdmissionCount> selectAdmissionCount() {
            List<AdmissionCount> list =repository.selectAdmissionCount();
            return list;
         } 
		
		 
		 @RequestMapping(value = "/selectAdmissionP_Num", method = RequestMethod.POST)
         public @ResponseBody List<Admission> selectAdmissionP_Num(String p_Num) {
            List<Admission> list =repository.selectAdmissionP_Num(p_Num);
            return list;
         } 
		 
		
		
	
	
}
