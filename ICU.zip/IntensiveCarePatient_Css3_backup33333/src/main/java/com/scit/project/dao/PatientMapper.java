package com.scit.project.dao;
import java.util.List;

import com.scit.project.vo.Patient;




public interface PatientMapper {
	public int insertPatient(Patient patient);
	public List<Patient> selectAllPatient();
	public Patient findPatientInRoom(String roomnum);
	public Patient selectAPatient(String rrn);
	public int patientLeave(String p_roomNum);
	public List<Patient> PatientListSearch(String p_Name);
	public int UpdatePatient(Patient patient);
	public List<Patient> checkRrn(String Rrn);
}
