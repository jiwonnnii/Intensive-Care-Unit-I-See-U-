package com.scit.project;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.scit.project.dao.RoomRepository;



/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	RoomRepository repository;
	

	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		
		return "home";
	}
	
	@RequestMapping(value = "index", method = RequestMethod.GET)
	public String signin(Model model) {
		int roomNum = repository.usableRoom();
		model.addAttribute("roomNum", roomNum);

		return "index";
	}
	
	
	
	
/*	@RequestMapping(value = "/reload", method = RequestMethod.GET)
	public String reload(HttpSession session) {
		String id = (String)session.getAttribute("m_Id");
		String pw = (String)session.getAttribute("m_Password");
		
		if(id != null && pw != null) {
			int roomNum = repository.usableRoom();
			
			
		}



		return "index";
	}*/
	
	
	
	
	
	@RequestMapping(value = "/goPatientInfo", method = RequestMethod.GET)
	public String goPatientInfo() {

		
		return "patientInfo";
	}
	@RequestMapping(value = "/gotoInsert", method = RequestMethod.GET)
	public String gotoInsert() {
		
		
		return "InsertPatient";
	}
	
	
	 @RequestMapping(value = "/goPatientList", method = RequestMethod.GET)
		public String goPatientList() {
			
			
			return "PatientList";
		}
	 
	 
	 @RequestMapping(value = "/checkForm", method = RequestMethod.GET)
	   public String checkForm() {
	         
	      return "checkRrn";
	   }  

	
	
}
