package com.scit.project;





import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.DiseaseRepository;
import com.scit.project.vo.Disease;


/**
 * Handles requests for the application home page.
 */
@Controller
public class DiseaseController {
	
	@Autowired
	DiseaseRepository repository;
	

	@RequestMapping(value ="DiseaseInsert",method = RequestMethod.POST)
	public @ResponseBody int  DiseaseInsert(@RequestBody ArrayList<Map<String, String>> disease) {
		System.out.println(disease);
		int result=0;
		List<Disease> check = repository.selectDisease(disease.get(0).get("p_Num"));
		String p_Num = disease.get(0).get("p_Num");
		if(check.size() > 0) {
			repository.DeleteDisease(p_Num);
			System.out.println("삭제"+1);
		}
		/*for(int i=0;i<disease.size();i++) {
			System.out.println("dd?"+disease.get(i));
		result =repository.DiseaseInsert(disease.get(i));
		
		System.out.println("추가"+1);
		}*/
		for(int i=0;i<disease.size();i++) {
			result =repository.DiseaseInsert(disease.get(i));
			System.out.println("추가"+1);

				}
		
		
		return result;
	}
	
	@RequestMapping(value ="selectDisease",method = RequestMethod.POST)
	public @ResponseBody List<Disease> selectDisease(String p_Num) {
		List<Disease>  result = repository.selectDisease(p_Num);
		System.out.println(result);

	return result;
	}
}
