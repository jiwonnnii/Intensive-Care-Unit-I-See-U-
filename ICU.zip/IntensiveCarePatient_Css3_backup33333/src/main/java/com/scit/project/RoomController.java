package com.scit.project;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.RoomRepository;
import com.scit.project.vo.Room;



/**
 * Handles requests for the application home page.
 */
@Controller
public class RoomController {
	
	@Autowired
	RoomRepository repository;
	

	@RequestMapping(value ="selectRoom",method = RequestMethod.POST)
	public @ResponseBody List<Room>  selectRoom() {
		List<Room> roomList = repository.selectRoom();
	
		return roomList;
	}
	

	
}

