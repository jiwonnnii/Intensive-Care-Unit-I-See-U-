package com.scit.project.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Room;






@Repository
public class RoomRepository {
	@Autowired
	SqlSession session;
	
	public List<Room> selectRoom() {
		RoomMapper mapper = session.getMapper(RoomMapper.class);
		List<Room> roomList =mapper.selectRoom();
		return roomList;
	}
	public int p_checkUpdate(String p_roomNum) {
		RoomMapper mapper=session.getMapper(RoomMapper.class);
		int result =mapper.p_checkUpdate(p_roomNum);
		return result;
	}
	public int roomLeave(String p_roomNum) {
		RoomMapper mapper = session.getMapper(RoomMapper.class);
		int result =mapper.roomLeave(p_roomNum);
		return result;
	}
	
	public int usableRoom() {
		RoomMapper mapper=session.getMapper(RoomMapper.class);
		int num = mapper.usableRoom(); 
		System.out.println("aaa");
		System.out.println(num);
		
		return num;
	}
	
}
