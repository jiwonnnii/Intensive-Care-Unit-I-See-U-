package com.scit.project.dao;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Admission;
import com.scit.project.vo.AdmissionCount;
import com.scit.project.vo.Patient;




@Repository
public class AdmissionRepository {
	@Autowired
	SqlSession session;
	

	public int insertAdmission(Patient patient) {
		AdmissionMapper mapper=session.getMapper(AdmissionMapper.class);
		int result = mapper.insertAdmission(patient);
		return result;
	}
	public int admissionEndDateUpdate(String p_Num) {
		AdmissionMapper mapper = session.getMapper(AdmissionMapper.class);
		int result = mapper.admissionEndDateUpdate(p_Num);
		return result;		
	}
	
	public List<AdmissionCount> selectAdmissionCount(){
	      AdmissionMapper mapper = session.getMapper(AdmissionMapper.class);
	      List<AdmissionCount> list = mapper.selectAdmissionCount();
	      return list;
	   }
	
	public List<Admission> selectAdmissionP_Num(String p_Num){
	      AdmissionMapper mapper = session.getMapper(AdmissionMapper.class);
	      List<Admission> list = mapper.selectAdmissionP_Num(p_Num);
	      return list;
	   }
	
	
	
}
