package com.scit.project.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Manager;





@Repository
public class ManagerRepository {
	@Autowired
	SqlSession session;
	
	public Manager ManagerLogin(Manager manager) {
		ManagerMapper mapper=session.getMapper(ManagerMapper.class);
		Manager result=mapper.selectManager(manager);
		return result;
	}

	
}
