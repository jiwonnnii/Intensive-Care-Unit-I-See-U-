package com.scit.project.vo;

public class Disease {
	private String p_Num;
	private String d_Name;
	public Disease() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Disease(String p_Num, String d_Name) {
		super();
		this.p_Num = p_Num;
		this.d_Name = d_Name;
	}
	public String getP_Num() {
		return p_Num;
	}
	public void setP_Num(String p_Num) {
		this.p_Num = p_Num;
	}
	public String getD_Name() {
		return d_Name;
	}
	public void setD_Name(String d_Name) {
		this.d_Name = d_Name;
	}
	@Override
	public String toString() {
		return "Disease [p_Num=" + p_Num + ", d_Name=" + d_Name + "]";
	}
	
	

}
