package com.scit.project.dao;



import java.util.List;
import java.util.Map;

import com.scit.project.vo.Disease;



public interface DiseaseMapper {
	public int DiseaseInsert(Map<String, String> disease);
	public List<Disease>  selectDisease(String p_Num);
	public int DeleteDisease(String p_Num);
	
	
}
