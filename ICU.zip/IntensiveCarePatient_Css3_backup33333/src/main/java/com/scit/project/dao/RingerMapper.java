package com.scit.project.dao;

import com.scit.project.vo.Heart;
import com.scit.project.vo.Ringer;

public interface RingerMapper {

	public int updateRingerState(Ringer ringer);

	
	//링거 장착상태
	public Ringer checkList(String p_roomNum);
	public int heartLeave(String p_roomNum);
	//링거장착 상태 YES로 체인지
	public int changeYesUseState(Ringer ringer);
	public int changeNoUseState(String roomNum);
	public int updateChangeEmergencyState(Heart heart);


	public int RingerFind(String roomNum);


	public String r_checkRingerStateBtn(String roomNum);
}
