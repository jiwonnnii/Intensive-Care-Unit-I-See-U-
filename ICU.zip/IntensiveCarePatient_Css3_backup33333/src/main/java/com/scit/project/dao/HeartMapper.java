package com.scit.project.dao;

import com.scit.project.vo.Heart;

public interface HeartMapper {
	public int insertBPM(Heart b);
	public Heart selectAllBPM();
	public Heart selectBPM(Heart bpm);
	public int updateBPM(Heart bpm);
	//public int checkList();
	public Heart checkList(String p_roomNum);
	public int heartLeave(String p_roomNum);
	public int changeYesUseState(String roomNum);
	public int changeNoUseState(String roomNum);
	public int updateChangeEmergencyState(Heart heart);
}
