package com.scit.project.vo;

public class AdmissionCount {
	   private String p_Num;
	   private String A_Count;
	   public AdmissionCount() {
	      super();
	      // TODO Auto-generated constructor stub
	   }
	   public AdmissionCount(String p_Num, String a_Count) {
	      super();
	      this.p_Num = p_Num;
	      A_Count = a_Count;
	   }
	   public String getP_Num() {
	      return p_Num;
	   }
	   public void setP_Num(String p_Num) {
	      this.p_Num = p_Num;
	   }
	   public String getA_Count() {
	      return A_Count;
	   }
	   public void setA_Count(String a_Count) {
	      A_Count = a_Count;
	   }
	   @Override
	   public String toString() {
	      return "AdmissionCount [p_Num=" + p_Num + ", A_Count=" + A_Count + "]";
	   }
	   
	      
	      
	   
	   

	}