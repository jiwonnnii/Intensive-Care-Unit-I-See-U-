package com.scit.project.vo;

public class Admission {
	private String a_Num;
	private String p_Num;
	private String a_RoomNum;
	private String a_StartDate;
	private String a_EndDate;
	public Admission(String a_Num, String p_Num, String a_RoomNum, String a_StartDate, String a_EndDate) {
		super();
		this.a_Num = a_Num;
		this.p_Num = p_Num;
		this.a_RoomNum = a_RoomNum;
		this.a_StartDate = a_StartDate;
		this.a_EndDate = a_EndDate;
	}
	public Admission() {
		super();
	}
	/**
	 * @return the a_Num
	 */
	public String getA_Num() {
		return a_Num;
	}
	/**
	 * @param a_Num the a_Num to set
	 */
	public void setA_Num(String a_Num) {
		this.a_Num = a_Num;
	}
	/**
	 * @return the p_Num
	 */
	public String getP_Num() {
		return p_Num;
	}
	/**
	 * @param p_Num the p_Num to set
	 */
	public void setP_Num(String p_Num) {
		this.p_Num = p_Num;
	}
	/**
	 * @return the a_RoomNum
	 */
	public String getA_RoomNum() {
		return a_RoomNum;
	}
	/**
	 * @param a_RoomNum the a_RoomNum to set
	 */
	public void setA_RoomNum(String a_RoomNum) {
		this.a_RoomNum = a_RoomNum;
	}
	/**
	 * @return the a_StartDate
	 */
	public String getA_StartDate() {
		return a_StartDate;
	}
	/**
	 * @param a_StartDate the a_StartDate to set
	 */
	public void setA_StartDate(String a_StartDate) {
		this.a_StartDate = a_StartDate;
	}
	/**
	 * @return the a_EndDate
	 */
	public String getA_EndDate() {
		return a_EndDate;
	}
	/**
	 * @param a_EndDate the a_EndDate to set
	 */
	public void setA_EndDate(String a_EndDate) {
		this.a_EndDate = a_EndDate;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Admission [a_Num=" + a_Num + ", p_Num=" + p_Num + ", a_RoomNum=" + a_RoomNum + ", a_StartDate="
				+ a_StartDate + ", a_EndDate=" + a_EndDate + "]";
	}

	
}
