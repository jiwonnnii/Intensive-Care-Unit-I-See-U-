package com.scit.project.vo;

public class Heart {
	private String p_roomnum;
	private String h_Bpm;
	private String h_useState;
	private String h_emergencyState;
	public Heart(String p_roomnum, String h_Bpm, String h_useState, String h_emergencyState) {
		super();
		this.p_roomnum = p_roomnum;
		this.h_Bpm = h_Bpm;
		this.h_useState = h_useState;
		this.h_emergencyState = h_emergencyState;
	}
	public Heart() {
		super();
	}
	/**
	 * @return the p_roomnum
	 */
	public String getP_roomnum() {
		return p_roomnum;
	}
	/**
	 * @param p_roomnum the p_roomnum to set
	 */
	public void setP_roomnum(String p_roomnum) {
		this.p_roomnum = p_roomnum;
	}
	/**
	 * @return the h_Bpm
	 */
	public String getH_Bpm() {
		return h_Bpm;
	}
	/**
	 * @param h_Bpm the h_Bpm to set
	 */
	public void setH_Bpm(String h_Bpm) {
		this.h_Bpm = h_Bpm;
	}
	/**
	 * @return the h_useState
	 */
	public String getH_useState() {
		return h_useState;
	}
	/**
	 * @param h_useState the h_useState to set
	 */
	public void setH_useState(String h_useState) {
		this.h_useState = h_useState;
	}
	/**
	 * @return the h_emergencyState
	 */
	public String getH_emergencyState() {
		return h_emergencyState;
	}
	/**
	 * @param h_emergencyState the h_emergencyState to set
	 */
	public void setH_emergencyState(String h_emergencyState) {
		this.h_emergencyState = h_emergencyState;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Heart [p_roomnum=" + p_roomnum + ", h_Bpm=" + h_Bpm + ", h_useState=" + h_useState
				+ ", h_emergencyState=" + h_emergencyState + "]";
	}
	
	

}
