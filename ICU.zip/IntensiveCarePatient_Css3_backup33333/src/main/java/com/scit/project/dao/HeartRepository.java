package com.scit.project.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Heart;
import com.scit.project.vo.Manager;



@Repository
public class HeartRepository {
	@Autowired
	SqlSession session;
	
	public Manager ManagerLogin(Manager manager) {
		ManagerMapper mapper=session.getMapper(ManagerMapper.class);
		Manager result=mapper.selectManager(manager);
		return result;
	}

	public Heart checkList(String roomNum) {
		HeartMapper mapper=session.getMapper(HeartMapper.class);
		System.out.println(" checkList roomNum" + roomNum);
		Heart result =mapper.checkList(roomNum);
		System.out.println("result" + result);
		return result;
	}
	public int insertBPM(Heart b) {
		HeartMapper mapper=session.getMapper(HeartMapper.class);
	    System.out.println("insertBPM"+b.getP_roomnum());
		int result =mapper.insertBPM(b);
		return result;
	}

	public int updateBPM(Heart heart) {
		// TODO Auto-generated method stub
		HeartMapper mapper=session.getMapper(HeartMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.updateBPM(heart);
		return result;
	}

	public int heartLeave(String p_roomNum) {
		HeartMapper mapper=session.getMapper(HeartMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.heartLeave(p_roomNum);
		return result;
	}

	public int changeYesUseState(String roomNum) {
		HeartMapper mapper=session.getMapper(HeartMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.changeYesUseState(roomNum);
		return result;
	}
	public int changeNoUseState(String roomNum) {
		HeartMapper mapper=session.getMapper(HeartMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.changeNoUseState(roomNum);
		return result;
	}
	
	public int updateChangeEmergencyState(Heart heart) {
		// TODO Auto-generated method stub
		HeartMapper mapper=session.getMapper(HeartMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.updateChangeEmergencyState(heart);
		return result;
	}

	
}
