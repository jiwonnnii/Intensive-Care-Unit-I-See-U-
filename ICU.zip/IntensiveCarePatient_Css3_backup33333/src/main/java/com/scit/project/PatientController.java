package com.scit.project;




import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.PatientRepository;
import com.scit.project.dao.RoomRepository;
import com.scit.project.vo.Patient;



/**
 * Handles requests for the application home page.
 */
@Controller
public class PatientController {
	
	@Autowired
	PatientRepository repository;
	
	@Autowired
	RoomRepository roomrepository;

	
	
	@RequestMapping(value ="insertPatient",method = RequestMethod.POST)
	public @ResponseBody int  insertpatient(Patient patient) {				// 환자 등록
		String rrn = patient.getP_Rrn();
		Patient temp = repository.selectAPatient(rrn);
		if(temp != null) {
			int result2 = repository.UpdatePatient(patient);
			roomrepository.p_checkUpdate(patient.getP_roomNum());
			return result2; 
			
		}
		int result =repository.insertPatient(patient);
		roomrepository.p_checkUpdate(patient.getP_roomNum());
		System.out.println("insertPatient메소드 들어옴"+result);
		return result;
	}
	
	
	@RequestMapping(value = "/getAvailableRoom", method = RequestMethod.POST)
	public @ResponseBody int getAvailableRoom() {
		int roomNum = roomrepository.usableRoom();
		System.out.println("룸개수" + roomNum);
		
		return roomNum;
	}
	
	

	@RequestMapping(value ="selectAllPatient",method = RequestMethod.POST)
	public @ResponseBody List<Patient>  selectAllPatient() {
	
		List<Patient> result =repository.selectAllPatient();
		/*for(Patient p : result) {
			System.out.println("controller" + p);
		}*/
		
		return result;
	}
	
	@RequestMapping(value ="/findPatientInRoom",method = RequestMethod.POST)
	public @ResponseBody String  findPatientInRoom(String room) {
		Patient result =repository.findPatientInRoom(room);
		
		if(result != null) {
			String p_Rrn = result.getP_Rrn();
			System.out.println("p_Rrn:"+p_Rrn);
			return p_Rrn;
		}else {
			return "";
		}
		
		
	}
	
	@RequestMapping(value ="selectAPatient",method = RequestMethod.POST)
	public @ResponseBody Patient  selectAPatient(String rrn, Model model) {
	
		Patient result =repository.selectAPatient(rrn);

		

		return result;
	}
	
	@RequestMapping(value ="/patientLeave",method = RequestMethod.POST)
	public @ResponseBody int  patientLeave(String p_roomNum) {
		int roomtemp = roomrepository.roomLeave(p_roomNum);
		int result = repository.patientLeave(p_roomNum);
		
		System.out.println(result);
		System.out.println(roomtemp);
		return result;
	}
	
	@RequestMapping(value ="/findRoomNum",method = RequestMethod.POST)
	public @ResponseBody Patient  findRoomNum(String p_roomNum) {
		Patient result=repository.findPatientInRoom(p_roomNum);
		System.out.println("퇴원환자 정보 가져오기 성공"+result);
		return result;
	}
	
	
	@RequestMapping(value ="/PatientListSearch",method = RequestMethod.GET)
	public @ResponseBody List<Patient>  PatientListSearch(String p_Name) {
		System.out.println(p_Name);
		List<Patient> result = repository.PatientListSearch(p_Name);
		
		
		return result;
	}
		
	  @RequestMapping(value = "/checkRrn", method = RequestMethod.GET)
	   public @ResponseBody List<Patient> checkRrn(String Rrn) {
	      System.out.println(1);
	      List<Patient> list =repository.checkRrn(Rrn);
	      System.out.println(list);
	      return list;
	   }   
	

	
}
