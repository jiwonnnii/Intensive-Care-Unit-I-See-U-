package com.scit.project.dao;



import java.util.List;

import com.scit.project.vo.Admission;
import com.scit.project.vo.AdmissionCount;
import com.scit.project.vo.Patient;

public interface AdmissionMapper {
	public int insertAdmission(Patient patient);
	public int admissionEndDateUpdate(String p_Num);
	public List<AdmissionCount> selectAdmissionCount();
	public List<Admission> selectAdmissionP_Num(String p_Num);
}
