package com.scit.project.vo;

public class Ringer {
	private String p_RoomNum;
	private String r_Name;
	private String r_Quantity;
	private String r_useState;
	private String r_ringerState;
	public Ringer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Ringer(String p_RoomNum, String r_Name, String r_Quantity, String r_useState, String r_ringerState) {
		super();
		this.p_RoomNum = p_RoomNum;
		this.r_Name = r_Name;
		this.r_Quantity = r_Quantity;
		this.r_useState = r_useState;
		this.r_ringerState = r_ringerState;
	}
	public String getP_RoomNum() {
		return p_RoomNum;
	}
	public void setP_RoomNum(String p_RoomNum) {
		this.p_RoomNum = p_RoomNum;
	}
	public String getR_Name() {
		return r_Name;
	}
	public void setR_Name(String r_Name) {
		this.r_Name = r_Name;
	}
	public String getR_Quantity() {
		return r_Quantity;
	}
	public void setR_Quantity(String r_Quantity) {
		this.r_Quantity = r_Quantity;
	}
	public String getR_useState() {
		return r_useState;
	}
	public void setR_useState(String r_useState) {
		this.r_useState = r_useState;
	}
	public String getR_ringerState() {
		return r_ringerState;
	}
	public void setR_ringerState(String r_ringerState) {
		this.r_ringerState = r_ringerState;
	}
	@Override
	public String toString() {
		return "Ringer [p_RoomNum=" + p_RoomNum + ", r_Name=" + r_Name + ", r_Quantity=" + r_Quantity + ", r_useState="
				+ r_useState + ", r_ringerState=" + r_ringerState + "]";
	}
	

}
