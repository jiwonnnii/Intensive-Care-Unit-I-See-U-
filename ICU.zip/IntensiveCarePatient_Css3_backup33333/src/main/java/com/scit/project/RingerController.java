package com.scit.project;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.PatientRepository;
import com.scit.project.dao.RingerRepository;
import com.scit.project.vo.Ringer;

import jssc.SerialPort;
import jssc.SerialPortException;

/**
 * Handles requests for the application home page.
 */
@Controller
public class RingerController {
	@Autowired
	PatientRepository repository;
	@Autowired
	RingerRepository ringerrepository;
	String total;
	String pulse;
	String water;
	String roomNum;

	/*@RequestMapping(value ="r_checkUseState",method = RequestMethod.POST)
	public @ResponseBody String  r_checkUseState(String roomNum) {
		Ringer r = ringerrepository.checkList(roomNum);
		//System.out.println("***************************" + h);
		String r_state = r.getR_useState();
		System.out.println("h_state 값 " + r_state);
		return r_state;
	}*/
	@RequestMapping(value ="r_checkUseStateBtn",method = RequestMethod.POST)
	public @ResponseBody String  r_checkUseStateBtn(String roomNum) {
		Ringer r = ringerrepository.checkList(roomNum);
		String r_state = r.getR_useState();
		System.out.println("체크" + r_state);
		//String h_state = h.getH_useState();
		//System.out.println("h_state 값 " + h_state);
		return r_state;
	}
	@RequestMapping(value ="r_useStateYesUpdate",method = RequestMethod.POST)
	public @ResponseBody  void r_useStateYesUpdate(String r_Name, String r_Quantity, String p_RoomNum ,Model model) {
		System.out.println("r_Name"+r_Name+"r_Quantity"+r_Quantity+"p_RoomNum"+p_RoomNum);
				Ringer r = new Ringer();
				r.setR_Name(r_Name);
				r.setR_Quantity(r_Quantity);
				r.setP_RoomNum(p_RoomNum);
		   System.out.println("컨트롤러 링거"+r);
		   int useStateUpdate_Yes = ringerrepository.changeYesUseState(r);
		   System.out.println("yes로 바꿔" + useStateUpdate_Yes);
           
	}
	@RequestMapping(value ="r_useStateNoUpdate",method = RequestMethod.POST)
	public @ResponseBody int  r_useStateNoUpdate(String roomNum) {
		   int result = 0;
		   int useStateUpdate_No = ringerrepository.changeNoUseState(roomNum);
           System.out.println("no로바꿔" +useStateUpdate_No);
          
           return result;
	}
	
	@RequestMapping(value ="r_checkRingerStateBtn",method = RequestMethod.POST)
	public @ResponseBody String  r_checkRingerStateBtn(String roomNum) {
		   int result = 0;
		   String r_checkRingerState = ringerrepository.r_checkRingerStateBtn(roomNum);
           
          
           return r_checkRingerState;
	}
	
	/*@RequestMapping(value ="checkEmergencyState",method = RequestMethod.POST)
	public @ResponseBody String  checkEmergencyState(String roomNum) {
		Heart h = heartrepository.checkList(roomNum);
		System.out.println("checkUseState" + h);
		String h_emergencyState = h.getH_emergencyState();
		System.out.println("h_ㅇ응급state 값 " + h_emergencyState);
		return h_emergencyState;
	}*/
	@RequestMapping(value ="RingerFind",method = RequestMethod.POST)
	public @ResponseBody Ringer  RingerFind(String roomNum) {
		   int result = 0;
		   Ringer r = ringerrepository.checkList(roomNum);
           /*System.out.println("no로바꿔" +useStateUpdate_No);*/
          
           return r;
	}
	
	
}
