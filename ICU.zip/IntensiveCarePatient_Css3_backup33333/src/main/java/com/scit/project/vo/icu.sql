﻿drop table Patient;
drop table Room;
drop table Heart;
drop table Manager;
drop table Ringer;
drop table Disease;
drop table Admission;
drop SEQUENCE p_Num_seq;
drop SEQUENCE a_Num_seq;


create table Patient(
p_Num varchar2(20) primary key,
p_Name varchar2(50),
p_Rrn varchar2(100),
p_Height number(30),
p_Weight number(30),
p_BloodType varchar2(30),
p_RoomNum VARCHAR2(20),
p_imgurl clob
);

create SEQUENCE p_Num_seq;

create table ROOM(
p_roomnum varchar2(20)
, r_check varchar2(20)
);

create table Heart(
h_Num varchar2(20) primary key,
p_Num varchar2(20),
constraint FK_Heart FOREIGN KEY(p_Num)
references Patient(p_Num),
h_Bpm number(30)
);

create table Manager(
m_Id varchar2(20) primary key,
m_Password varchar2(50)
);

create table Admission(
a_Num varchar2(20) primary key,
p_Num varchar2(20), 
constraint FK_Admission FOREIGN KEY(p_Num)
references Patient(p_Num),
a_RoomNum varchar2(20),
a_StartDate date default sysdate,
a_EndDate date
);

create SEQUENCE a_Num_seq;

create table Ringer(
r_Num varchar2(20) primary key,
p_Num varchar2(20),
constraint FK_Riger FOREIGN KEY(p_Num)
references Patient(p_Num),
r_Name varchar2(50),
r_Quantity number(20)
);

create table Disease(
d_Num varchar2(20) primary key,
p_Num varchar2(20),
constraint FK_Disease FOREIGN KEY(p_Num)
references Patient(p_Num),
d_Name varchar2(50)
);


commit;



insert into Manager values(
'2',
'2'
);




insert into room(p_roomnum,r_check)values('1-1','N');
insert into room(p_roomnum,r_check)values('1-2','N');
insert into room(p_roomnum,r_check)values('1-3','N');
insert into room(p_roomnum,r_check)values('1-4','N');
insert into room(p_roomnum,r_check)values('1-5','N');
insert into room(p_roomnum,r_check)values('1-6','N');
insert into room(p_roomnum,r_check)values('1-7','N');
insert into room(p_roomnum,r_check)values('1-8','N');
insert into room(p_roomnum,r_check)values('1-9','N');
insert into room(p_roomnum,r_check)values('1-10','N');
insert into room(p_roomnum,r_check)values('2-1','N');
insert into room(p_roomnum,r_check)values('2-2','N');
insert into room(p_roomnum,r_check)values('2-3','N');
insert into room(p_roomnum,r_check)values('2-4','N');
insert into room(p_roomnum,r_check)values('2-5','N');
insert into room(p_roomnum,r_check)values('2-6','N');
insert into room(p_roomnum,r_check)values('2-7','N');
insert into room(p_roomnum,r_check)values('2-8','N');
insert into room(p_roomnum,r_check)values('2-9','N');
insert into room(p_roomnum,r_check)values('2-10','N');


select * from patient;