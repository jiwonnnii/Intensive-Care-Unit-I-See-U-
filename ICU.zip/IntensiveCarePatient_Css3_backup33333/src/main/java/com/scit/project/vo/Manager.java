package com.scit.project.vo;

public class Manager {
	private String m_Id;
	private String m_Password;
	public Manager(String m_Id, String m_Password) {
		super();
		this.m_Id = m_Id;
		this.m_Password = m_Password;
	}
	public Manager() {
		super();
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getM_Password() {
		return m_Password;
	}
	public void setM_Password(String m_Password) {
		this.m_Password = m_Password;
	}
	@Override
	public String toString() {
		return "Manager [m_Id=" + m_Id + ", m_Password=" + m_Password + "]";
	}
	
	

}
