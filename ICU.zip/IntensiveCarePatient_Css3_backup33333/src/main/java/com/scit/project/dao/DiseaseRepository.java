package com.scit.project.dao;


import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Disease;




@Repository
public class DiseaseRepository {
	@Autowired
	SqlSession session;
	

	public int DiseaseInsert(Map<String, String> disease) {
		DiseaseMapper mapper=session.getMapper(DiseaseMapper.class);
		int result = mapper.DiseaseInsert(disease);
		return result;
	}
	public List<Disease>  selectDisease(String p_Num) {
		DiseaseMapper mapper=session.getMapper(DiseaseMapper.class);
		List<Disease>  result = mapper.selectDisease(p_Num);
		return result;
	}
	public int DeleteDisease(String p_Num) {
		DiseaseMapper mapper=session.getMapper(DiseaseMapper.class);
		int result = mapper.DeleteDisease(p_Num);
		return result;
	}

	
}
