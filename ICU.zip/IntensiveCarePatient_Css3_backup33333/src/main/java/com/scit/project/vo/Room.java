package com.scit.project.vo;

public class Room {
	private String p_roomNum;
	private String r_check;
	public Room(String p_roomNum, String r_check) {
		super();
		this.p_roomNum = p_roomNum;
		this.r_check = r_check;
	}
	public Room() {
		super();
	}
	public String getP_roomNum() {
		return p_roomNum;
	}
	public void setP_roomNum(String p_roomNum) {
		this.p_roomNum = p_roomNum;
	}
	public String getR_check() {
		return r_check;
	}
	public void setR_check(String r_check) {
		this.r_check = r_check;
	}
	@Override
	public String toString() {
		return "Room [p_roomNum=" + p_roomNum + ", r_check=" + r_check + "]";
	}
	
	
}
