package com.scit.project.vo;
public class Patient {
	private String p_Num;
	private String p_Name;
	private String p_Rrn;
	private int p_Height;
	private int p_Weight;
	private String p_BloodType;
	private String p_roomNum;
	private String p_imgurl;
	
	
	public Patient(String p_Num, String p_Name, String p_Rrn, int p_Height, int p_Weight, String p_BloodType,
			String p_roomNum, String p_imgurl) {
		super();
		this.p_Num = p_Num;
		this.p_Name = p_Name;
		this.p_Rrn = p_Rrn;
		this.p_Height = p_Height;
		this.p_Weight = p_Weight;
		this.p_BloodType = p_BloodType;
		this.p_roomNum = p_roomNum;
		this.p_imgurl = p_imgurl;
	}
	public Patient() {
		super();
	}
	/**
	 * @return the p_Num
	 */
	public String getP_Num() {
		return p_Num;
	}
	/**
	 * @param p_Num the p_Num to set
	 */
	public void setP_Num(String p_Num) {
		this.p_Num = p_Num;
	}
	/**
	 * @return the p_Name
	 */
	public String getP_Name() {
		return p_Name;
	}
	/**
	 * @param p_Name the p_Name to set
	 */
	public void setP_Name(String p_Name) {
		this.p_Name = p_Name;
	}
	/**
	 * @return the p_Rrn
	 */
	public String getP_Rrn() {
		return p_Rrn;
	}
	/**
	 * @param p_Rrn the p_Rrn to set
	 */
	public void setP_Rrn(String p_Rrn) {
		this.p_Rrn = p_Rrn;
	}
	/**
	 * @return the p_Height
	 */
	public int getP_Height() {
		return p_Height;
	}
	/**
	 * @param p_Height the p_Height to set
	 */
	public void setP_Height(int p_Height) {
		this.p_Height = p_Height;
	}
	/**
	 * @return the p_Weight
	 */
	public int getP_Weight() {
		return p_Weight;
	}
	/**
	 * @param p_Weight the p_Weight to set
	 */
	public void setP_Weight(int p_Weight) {
		this.p_Weight = p_Weight;
	}
	/**
	 * @return the p_BloodType
	 */
	public String getP_BloodType() {
		return p_BloodType;
	}
	/**
	 * @param p_BloodType the p_BloodType to set
	 */
	public void setP_BloodType(String p_BloodType) {
		this.p_BloodType = p_BloodType;
	}
	/**
	 * @return the p_roomNum
	 */
	public String getP_roomNum() {
		return p_roomNum;
	}
	/**
	 * @param p_roomNum the p_roomNum to set
	 */
	public void setP_roomNum(String p_roomNum) {
		this.p_roomNum = p_roomNum;
	}
	/**
	 * @return the p_imgurl
	 */
	public String getP_imgurl() {
		return p_imgurl;
	}
	/**
	 * @param p_imgurl the p_imgurl to set
	 */
	public void setP_imgurl(String p_imgurl) {
		this.p_imgurl = p_imgurl;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Patient [p_Num=" + p_Num + ", p_Name=" + p_Name + ", p_Rrn=" + p_Rrn + ", p_Height=" + p_Height
				+ ", p_Weight=" + p_Weight + ", p_BloodType=" + p_BloodType + ", p_roomNum=" + p_roomNum + ", p_imgurl="
				+ p_imgurl + "]";
	}
	
	

}
