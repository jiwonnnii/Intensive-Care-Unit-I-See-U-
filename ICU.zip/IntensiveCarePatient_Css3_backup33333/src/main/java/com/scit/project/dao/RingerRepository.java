package com.scit.project.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Heart;
import com.scit.project.vo.Manager;
import com.scit.project.vo.Ringer;



@Repository
public class RingerRepository {
	@Autowired
	SqlSession session;
	
	public Manager ManagerLogin(Manager manager) {
		ManagerMapper mapper=session.getMapper(ManagerMapper.class);
		Manager result=mapper.selectManager(manager);
		return result;
	}
	//룸넘버로 검색 Yes 인지 No인지
	public Ringer checkList(String roomNum) {
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		System.out.println("들어가기전"+roomNum);
		Ringer result =mapper.checkList(roomNum);
		System.out.println("들어간후"+result);
		return result;
	}

	//useState 변화
	public int updateRingerState(Ringer ringer) {
		// TODO Auto-generated method stub
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		System.out.println(ringer);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.updateRingerState(ringer);
		System.out.println(result);
		return result;
	}

	public int heartLeave(String p_roomNum) {
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.heartLeave(p_roomNum);
		return result;
	}
	
	//장착 No일시 Yes 로 체인지
	public int changeYesUseState(Ringer ringer) {
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		System.out.println("링거 체인지하러 감 레포지"+ringer);
		int result =mapper.changeYesUseState(ringer);
		System.out.println("착용 링거 돌아올때"+result);
		return result;
	}
	public int changeNoUseState(String roomNum) {
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.changeNoUseState(roomNum);
		return result;
	}
	
	public int updateChangeEmergencyState(Heart heart) {
		// TODO Auto-generated method stub
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.updateChangeEmergencyState(heart);
		return result;
	}
	public int RingerFind(String roomNum) {
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		//System.out.println("updateBPM        "+heart.getP_roomnum()+"      updateBPM    "+heart.getH_Bpm());
		int result =mapper.RingerFind(roomNum);
		return result;
	}
	public String r_checkRingerStateBtn(String roomNum) {
		RingerMapper mapper=session.getMapper(RingerMapper.class);
		System.out.println("들어가기전"+roomNum);
		String result =mapper.r_checkRingerStateBtn(roomNum);
		System.out.println("들어간후"+result);
		return result;
	}

	
}
