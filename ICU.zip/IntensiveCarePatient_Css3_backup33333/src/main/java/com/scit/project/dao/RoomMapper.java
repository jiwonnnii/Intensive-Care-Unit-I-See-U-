package com.scit.project.dao;

import java.util.List;

import com.scit.project.vo.Room;



public interface RoomMapper {
	public List<Room> selectRoom();
	public int p_checkUpdate(String p_roomNum);
	public int roomLeave(String p_roomNum);
	
	public int 	usableRoom();
}
