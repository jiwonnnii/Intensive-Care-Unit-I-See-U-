package com.scit.project.dao;

import com.scit.project.vo.Manager;

public interface ManagerMapper {
	public Manager selectManager(Manager manager);
}
