package com.scit.project.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.project.vo.Patient;




@Repository
public class PatientRepository {
	@Autowired
	SqlSession session;
	
	public int insertPatient(Patient patient) {
		PatientMapper mapper =session.getMapper(PatientMapper.class);
		int result =mapper.insertPatient(patient);
		return result;
	}

	public List<Patient> selectAllPatient(){
		PatientMapper mapper = session.getMapper(PatientMapper.class);
		List<Patient> result = mapper.selectAllPatient();
		System.out.println(result);
		return result;
				
	}
	

	public Patient findPatientInRoom(String roomnum) {
		PatientMapper mapper = session.getMapper(PatientMapper.class);
		Patient result = mapper.findPatientInRoom(roomnum);
		System.out.println("룸의 ?���?" +result );
		return result;
	}
	
	public Patient selectAPatient(String rrn) {
		PatientMapper mapper = session.getMapper(PatientMapper.class);
		Patient result = mapper.selectAPatient(rrn);
		System.out.println("룸의 ?���?" +result );
		return result;
	}
	
	public int patientLeave(String p_roomNum) {
		PatientMapper mapper = session.getMapper(PatientMapper.class);
		int result = mapper.patientLeave(p_roomNum);
		return result;
	}
	public List<Patient> PatientListSearch(String p_Name){
		PatientMapper mapper = session.getMapper(PatientMapper.class);
		List<Patient> result = mapper.PatientListSearch(p_Name);
		return result;
	}
	public int UpdatePatient(Patient patient) {
		PatientMapper mapper = session.getMapper(PatientMapper.class);
		int result = mapper.UpdatePatient(patient);
		return result;
	}
	
	public List<Patient> checkRrn(String Rrn) {
	      // TODO Auto-generated method stub
	      PatientMapper mapper = session.getMapper(PatientMapper.class);
	      List<Patient> list = mapper.checkRrn(Rrn);
	      return list; 
	   }
}
