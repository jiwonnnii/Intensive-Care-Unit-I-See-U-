package com.scit.project;


import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.HeartRepository;
import com.scit.project.dao.ManagerRepository;
import com.scit.project.dao.RingerRepository;
import com.scit.project.dao.RoomRepository;
import com.scit.project.vo.Heart;
import com.scit.project.vo.Manager;
import com.scit.project.vo.Ringer;

import jssc.SerialPort;
import jssc.SerialPortException;


/**
 * Handles requests for the application home page.
 */
@Controller
public class ManagerController {
	
	@Autowired
	ManagerRepository repository;

	@Autowired
	HeartRepository heartrepository;
	@Autowired
	RingerRepository ringerrepository;
	@Autowired
	SqlSession session;
	   
	String total;
	String pulse;
	String water;
	String roomNum;
	
	@RequestMapping(value = "managerCheck", method = RequestMethod.POST)
	public @ResponseBody Manager managerCheck(Manager manager) {
		System.out.println("managerCheck들어옴");
		Manager m = repository.ManagerLogin(manager);
		System.out.println(m);
		return m;

	}
	@RequestMapping(value = "ManagerLogin", method = RequestMethod.POST)
	public String ManagerLogin(Manager manager,HttpSession session) {
		Manager m = repository.ManagerLogin(manager);
		if(m!=null) {
			session.setAttribute("m_Id", m.getM_Id());
			session.setAttribute("m_Password ", m.getM_Password());
			return "index";
		}else {
			return "login"; 
		}
	}
	@RequestMapping(value = "getPulseWaterOfRoom", method = RequestMethod.POST)
	public void getPulseWaterOfRoom(Model model) {
		System.out.println("getPulseWaterOfRoom들어옴");		  
	    SerialPort serialPort = new SerialPort("COM5");

	      try {
	         // opening port
	         serialPort.openPort();

	         serialPort.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
	               SerialPort.PARITY_NONE);

	         serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN | SerialPort.FLOWCONTROL_RTSCTS_OUT);

	         new ReadThread(serialPort, model,heartrepository).start();

	      } catch (SerialPortException ex) {
	         System.out.println("Error in writing data to port: " + ex);
	      }

	}
	 class ReadThread extends Thread {
   
	      SerialPort serial;
	      Model model;
	      HeartRepository roomrepository;

	      String readed = "";
	      //String pulse="";
	      //String water = "";

	      ReadThread(SerialPort serial, Model model,HeartRepository roomrepository) {
	         this.serial = serial;
	         this.model = model;
	         this.roomrepository = roomrepository;
	      }

	      public void run() {
	          try {
	        	  //int index=0;
	                   while (true) {
	                       byte[] read = serial.readBytes(); //(1): 8/1/,/1  //(): 88,1 or 83,/1 or 8/3,1 or 81/,/1
	                       if (read != null && read.length > 0) {
	                          String r = new String(read);
	                          total += r;
	                          
	                          if(total.length()>10&&total.contains(",")) { //9
	                        	      total=total.trim();
	                             if(total.split(",").length>1) {
	                            	
	                                    total=total.trim();
	                                    total= total.replaceAll("null","");
	                                  
	                                    roomNum = total.split(",")[0];
		                                pulse = total.split(",")[1];
		                                water = total.split(",")[2];
	                              
		                                if(roomNum.contains("-")&&roomNum.length()==3&&pulse.length()>=1&&water.length()>=1 && (water.equals("1") || water.equals("0"))) {
			                                System.out.println("roomNum : " + roomNum +"  length : "+roomNum.length()+ " " +"pulse : " + pulse + " " + "water : " + water);
		                                	System.out.println("roomNum"+roomNum);
			                                Heart h_check = heartrepository.checkList(roomNum);
			                                Ringer r_check = ringerrepository.checkList(roomNum);
		                                	System.out.println("serial에 나오는 값 : "+h_check);
		                                	if(h_check.getH_useState().equals("Yes")){
		                                		
		                                		System.out.println("룸 안에 환자가 심장박동센서를 착용중이다");
		                                		try{
					                                h_check.setH_Bpm(pulse);
						                            System.out.println("heart!!!"+h_check);
						                            heartrepository.updateBPM(h_check);
						                            /*if(h_check==null) {             
					                                    heartrepository.insertBPM(h_check);
					                                }else {
					                                	heartrepository.updateBPM(h_check);
					                                }*/					             
						                            int h_check_bpm = Integer.parseInt(h_check.getH_Bpm());
						                            if(h_check_bpm==0 || h_check_bpm > 100 || h_check_bpm < 50)
						                            {
						                            	System.out.println("응급응급응급응급::: "+h_check_bpm);
						                            	h_check.setH_emergencyState("Yes");
						                            	heartrepository.updateChangeEmergencyState(h_check);
						                            }else {
						                            	System.out.println("정상정상정상::: "+h_check_bpm);
						                            	h_check.setH_emergencyState("No");
						                            	heartrepository.updateChangeEmergencyState(h_check);
						                            }   
						                            	
				                                    total="";
		                                		}catch(Exception e) {
					                                  e.printStackTrace();
					                            }

		                                	}else {
		                                		h_check.setH_emergencyState("No");
				                            	heartrepository.updateChangeEmergencyState(h_check);
		                                	}
		                                	
		                                	
		                                	// 심박아두이노
		                                	if(r_check.getR_useState().equals("Yes")){
		                                		System.out.println("룸 안에 환자가 심장박동센서를 착용중이다");
		                                		try{
					                                r_check.setR_ringerState(water);
						                            System.out.println("heart!!!"+r_check);
						                            ringerrepository.updateRingerState(r_check);
						                            /*if(h_check==null) {             
					                                    heartrepository.insertBPM(h_check);
					                                }else {
					                                	heartrepository.updateBPM(h_check);
					                                }*/					             
						                            String r_check_RingerState = r_check.getR_ringerState();
						                            System.out.println(r_check_RingerState);
						                            if(r_check_RingerState.equals("0"))
						                            {
						                            	System.out.println("응급응급응급응급::: "+r_check_RingerState);
						                            	/*r_check.setH_emergencyState("Yes");
						                            	heartrepository.updateChangeEmergencyState(h_check);*/
						                            }else {
						                            	System.out.println("정상정상정상::: "+r_check_RingerState);
						                            	/*h_check.setH_emergencyState("No");
						                            	heartrepository.updateChangeEmergencyState(h_check);*/
						                            }   
						                            	
				                                    total="";
		                                		}catch(Exception e) {
					                                  e.printStackTrace();
					                            }

		                                	}/*else {
		                                		r_check.setH_emergencyState("No");
				                            	heartrepository.updateChangeEmergencyState(h_check);
		                                	}	  */   
		                                	
		                                	
		                                }
		                                   total="";
		                                   Thread.sleep(100);
		                                   
	                             }           
	                          }
	                           readed+=r;
	                           if(readed.contains("Bye!")||readed.contains("Fail")) {                          
	                        	   		break;
	                           }
	                       }
	                    }
	                    serial.closePort();
	             
	             
	          } catch (Exception e) {
	             e.printStackTrace();
	          }
	       }
	   }

	 @RequestMapping(value = "/viewData", method = RequestMethod.POST, produces = "application/text; charset=utf8")
	 public @ResponseBody String viewData() {  
	      return total;
	 }
	 @RequestMapping(value = "/viewPulse", method = RequestMethod.POST, produces = "application/text; charset=utf8")
	 public @ResponseBody String viewPulse(String roomNum) {  
		  Heart h = heartrepository.checkList(roomNum);
		 
		  String h_state = h.getH_useState();
		 /* if(h_state.equals("No")) {
			  return "미착용";
		  }*/
		  return h.getH_Bpm();
	  }
	 @RequestMapping(value = "/viewWater", method = RequestMethod.POST, produces = "application/text; charset=utf8")
	 public @ResponseBody String viewWater() {  
		  return water;
	 }
	
		
	
	
	
	
	@RequestMapping(value = "/Logout", method = RequestMethod.GET)
	public String Logout(HttpSession session) {
		
		session.invalidate();
		
		return "home";
	}
	

	
}
