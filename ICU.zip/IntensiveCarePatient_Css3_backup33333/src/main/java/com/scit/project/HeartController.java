package com.scit.project;



import java.util.List;
import java.util.concurrent.SynchronousQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scit.project.dao.HeartRepository;
import com.scit.project.dao.PatientRepository;
import com.scit.project.vo.Heart;


/**
 * Handles requests for the application home page.
 */
@Controller
public class HeartController {
	@Autowired
	PatientRepository repository;
	@Autowired
	HeartRepository heartrepository;
	String total;
	String pulse;
	String water;
	String roomNum;

	@RequestMapping(value ="checkUseState",method = RequestMethod.POST)
	public @ResponseBody String  checkUseState(String roomNum) {
		Heart h = heartrepository.checkList(roomNum);
		//System.out.println("***************************" + h);
		String h_state = h.getH_useState();
		System.out.println("h_state 값 " + h_state);
		return h_state;
	}
	@RequestMapping(value ="checkUseStateBtn",method = RequestMethod.POST)
	public @ResponseBody String  checkUseStateBtn(String roomNum) {
		Heart h = heartrepository.checkList(roomNum);
		String h_state = h.getH_useState();
		System.out.println("***************************" + h_state);
		//String h_state = h.getH_useState();
		//System.out.println("h_state 값 " + h_state);
		return h_state;
	}
	@RequestMapping(value ="useStateYesUpdate",method = RequestMethod.POST)
	public @ResponseBody  void useStateYesUpdate(String roomNum,Model model) {
		   
		   int useStateUpdate_Yes = heartrepository.changeYesUseState(roomNum);
		   System.out.println("8888888888888888888888888" + useStateUpdate_Yes);
           
	}
	@RequestMapping(value ="useStateNoUpdate",method = RequestMethod.POST)
	public @ResponseBody int  useStateNoUpdate(String roomNum) {
		   int result = 0;
		   int useStateUpdate_No = heartrepository.changeNoUseState(roomNum);
           System.out.println("/////////////////////////////");
          
           return result;
	}

	@RequestMapping(value ="checkEmergencyState", method = RequestMethod.POST)
	public @ResponseBody String  checkEmergencyState(String roomNum) {
		Heart h = heartrepository.checkList(roomNum);
		System.out.println("checkUseState" + h);
		String h_emergencyState = h.getH_emergencyState();
		System.out.println("h_ㅇ응급state 값 " + h_emergencyState);
		return h_emergencyState;
	}
}
